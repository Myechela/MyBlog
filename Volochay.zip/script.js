// Инициализация данных в LocalStorage, если пусто
if (!localStorage.getItem('posts')) {
    const defaultPosts = [
        {
            id: Date.now(),
            title: "Мой первый пост в ИС",
            content: "Привет! Меня зовут Александр. Это мой первый проект на JavaScript.",
            image: "https://images.unsplash.com/photo-1484417894907-623942c8ee29?w=500"
        }
    ];
    localStorage.setItem('posts', JSON.stringify(defaultPosts));
}

// Получение постов
function getPosts() {
    return JSON.parse(localStorage.getItem('posts'));
}

// Отрисовка постов на главной
function renderPosts() {
    const container = document.getElementById('posts-container');
    const posts = getPosts();
    container.innerHTML = '';

    posts.forEach(post => {
        container.innerHTML += `
            <div class="col-md-4 post-card">
                <div class="card h-100 shadow-sm">
                    <img src="${post.image}" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">${post.title}</h5>
                        <p class="card-text text-truncate">${post.content}</p>
                        <a href="post.html?id=${post.id}" class="btn btn-primary btn-sm">Читать дальше</a>
                    </div>
                </div>
            </div>
        `;
    });
}


function initEditor() {
    const urlParams = new URLSearchParams(window.location.search);
    const editId = urlParams.get('id');
    const form = document.getElementById('post-form');
    const posts = getPosts();

    if (editId) {
        document.getElementById('form-title').innerText = "Редактировать пост";
        const post = posts.find(p => p.id == editId);
        document.getElementById('post-title').value = post.title;
        document.getElementById('post-image').value = post.image;
        document.getElementById('post-content').value = post.content;
    }

    form.onsubmit = (e) => {
        e.preventDefault();
        
        const newPost = {
            id: editId ? parseInt(editId) : Date.now(),
            title: document.getElementById('post-title').value,
            image: document.getElementById('post-image').value,
            content: document.getElementById('post-content').value
        };

        if (editId) {
            const index = posts.findIndex(p => p.id == editId);
            posts[index] = newPost;
        } else {
            posts.push(newPost);
        }

        localStorage.setItem('posts', JSON.stringify(posts));
        window.location.href = 'index.html';
    };
}


function renderFullPost() {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');
    const post = getPosts().find(p => p.id == id);
    const container = document.getElementById('full-post-container');

    if (!post) return;

    container.innerHTML = `
        <img src="${post.image}" class="img-fluid w-100 shadow-sm">
        <h1>${post.title}</h1>
        <p class="lead mt-4">${post.content}</p>
        <hr>
        <div class="d-flex gap-2">
            <a href="index.html" class="btn btn-secondary">Назад</a>
            <a href="editor.html?id=${post.id}" class="btn btn-warning">Редактировать</a>
            <button onclick="deletePost(${post.id})" class="btn btn-danger">Удалить</button>
        </div>
    `;
}

// Удаление поста
function deletePost(id) {
    if (confirm('Удалить этот пост?')) {
        let posts = getPosts();
        posts = posts.filter(p => p.id !== id);
        localStorage.setItem('posts', JSON.stringify(posts));
        window.location.href = 'index.html';
    }
}